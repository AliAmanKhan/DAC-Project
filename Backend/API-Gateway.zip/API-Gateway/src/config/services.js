module.exports = {
  USER_SERVICE: "http://localhost:8080",
  PITCH_SERVICE: "http://localhost:8081",
  COLLAB_SERVICE: "http://localhost:8083",
  MESSAGE_SERVICE: "http://localhost:8084",
};
